// AUTO-GENERATED from icons/menu-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function MenuIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M16 13.6436C16.4141 13.6436 16.7499 13.9794 16.75 14.3936C16.75 14.8078 16.4142 15.1436 16 15.1436H6C5.58579 15.1436 5.25 14.8078 5.25 14.3936C5.25011 13.9794 5.58585 13.6436 6 13.6436H16ZM18 8.84375C18.4142 8.84375 18.75 9.17954 18.75 9.59375C18.75 10.008 18.4142 10.3438 18 10.3438H6C5.58579 10.3438 5.25 10.008 5.25 9.59375C5.25 9.17954 5.58579 8.84375 6 8.84375H18Z" fill="currentColor"/>
    </Icon>
  );
}
