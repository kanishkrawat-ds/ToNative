// AUTO-GENERATED from icons/error-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ErrorIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 20.5004C16.6944 20.5004 20.5 16.6948 20.5 12.0004C20.5 7.30595 16.6944 3.50037 12 3.50037C7.30558 3.50037 3.5 7.30595 3.5 12.0004C3.5 16.6948 7.30558 20.5004 12 20.5004ZM12 22.0004C17.5228 22.0004 22 17.5232 22 12.0004C22 6.47752 17.5228 2.00037 12 2.00037C6.47715 2.00037 2 6.47752 2 12.0004C2 17.5232 6.47715 22.0004 12 22.0004Z" fill="currentColor"/> <path d="M11 15.5C11 14.9477 11.4477 14.5 12 14.5C12.5523 14.5 13 14.9477 13 15.5C13 16.0523 12.5523 16.5 12 16.5C11.4477 16.5 11 16.0523 11 15.5Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M12 12.75C11.5858 12.75 11.25 12.4142 11.25 12V8C11.25 7.58579 11.5858 7.25 12 7.25C12.4142 7.25 12.75 7.58579 12.75 8V12C12.75 12.4142 12.4142 12.75 12 12.75Z" fill="currentColor"/>
    </Icon>
  );
}
