// AUTO-GENERATED from icons/inr-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function InrIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M5.25 3.5C5.25 3.08579 5.58579 2.75 6 2.75H18C18.4142 2.75 18.75 3.08579 18.75 3.5C18.75 3.91421 18.4142 4.25 18 4.25H6C5.58579 4.25 5.25 3.91421 5.25 3.5Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M5.25 8C5.25 7.58579 5.58579 7.25 6 7.25H18C18.4142 7.25 18.75 7.58579 18.75 8C18.75 8.41421 18.4142 8.75 18 8.75H6C5.58579 8.75 5.25 8.41421 5.25 8Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M7.25 3.5C7.25 3.08579 7.58579 2.75 8 2.75H10C12.8995 2.75 15.25 5.1005 15.25 8C15.25 10.8995 12.8995 13.25 10 13.25H6.5C6.08579 13.25 5.75 12.9142 5.75 12.5C5.75 12.0858 6.08579 11.75 6.5 11.75H10C12.0711 11.75 13.75 10.0711 13.75 8C13.75 5.92893 12.0711 4.25 10 4.25H8C7.58579 4.25 7.25 3.91421 7.25 3.5Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M6.01986 11.9238C6.33807 11.6587 6.81099 11.7017 7.07617 12.0199L14.5762 21.0199C14.8413 21.3381 14.7983 21.811 14.4801 22.0762C14.1619 22.3413 13.689 22.2983 13.4238 21.9801L5.92383 12.9801C5.65866 12.6619 5.70165 12.189 6.01986 11.9238Z" fill="currentColor"/>
    </Icon>
  );
}
