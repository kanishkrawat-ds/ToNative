// AUTO-GENERATED from icons/equals-outline-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function EqualsOutlineIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M18.75 8.9998C18.75 9.41402 18.4142 9.7498 18 9.7498L6 9.7498C5.58579 9.7498 5.25 9.41402 5.25 8.9998C5.25 8.58559 5.58579 8.2498 6 8.2498L18 8.2498C18.4142 8.2498 18.75 8.58559 18.75 8.9998Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M18.75 14.9998C18.75 15.414 18.4142 15.7498 18 15.7498L6 15.7498C5.58579 15.7498 5.25 15.414 5.25 14.9998C5.25 14.5856 5.58579 14.2498 6 14.2498L18 14.2498C18.4142 14.2498 18.75 14.5856 18.75 14.9998Z" fill="currentColor"/>
    </Icon>
  );
}
