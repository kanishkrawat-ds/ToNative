// AUTO-GENERATED from icons/arrow-upward-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowUpwardIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M11.0509 4.95409C11.5498 4.37208 12.4502 4.37207 12.9491 4.95409L18.5695 11.5112C18.839 11.8257 18.8026 12.2992 18.4881 12.5687C18.1736 12.8383 17.7001 12.8019 17.4306 12.4874L12.75 7.02673L12.75 18.9993C12.75 19.4135 12.4142 19.7493 12 19.7493C11.5858 19.7493 11.25 19.4135 11.25 18.9993L11.25 7.02673L6.56946 12.4874C6.29989 12.8019 5.82641 12.8383 5.51192 12.5687C5.19743 12.2992 5.161 11.8257 5.43057 11.5112L11.0509 4.95409Z" fill="currentColor"/>
    </Icon>
  );
}
