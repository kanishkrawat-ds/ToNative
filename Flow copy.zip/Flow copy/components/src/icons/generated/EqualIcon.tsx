// AUTO-GENERATED from icons/equal.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function EqualIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM16.25 9.5C16.25 9.91421 15.9142 10.25 15.5 10.25H8.5C8.08579 10.25 7.75 9.91421 7.75 9.5C7.75 9.08579 8.08579 8.75 8.5 8.75L15.5 8.75C15.9142 8.75 16.25 9.08579 16.25 9.5ZM15.5 15.25C15.9142 15.25 16.25 14.9142 16.25 14.5C16.25 14.0858 15.9142 13.75 15.5 13.75H8.5C8.08579 13.75 7.75 14.0858 7.75 14.5C7.75 14.9142 8.08579 15.25 8.5 15.25H15.5Z" fill="currentColor"/>
    </Icon>
  );
}
