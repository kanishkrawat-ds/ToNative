// AUTO-GENERATED from icons/radio-button-checked-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function RadioButtonCheckedFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M12 7C9.23858 7 7 9.23858 7 12C7 14.7614 9.23858 17 12 17C14.7614 17 17 14.7614 17 12C17 9.23858 14.7614 7 12 7Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM12 20.3333C7.39763 20.3333 3.66667 16.6024 3.66667 12C3.66667 7.39763 7.39763 3.66667 12 3.66667C16.6024 3.66667 20.3333 7.39763 20.3333 12C20.3333 16.6024 16.6024 20.3333 12 20.3333Z" fill="currentColor"/>
    </Icon>
  );
}
