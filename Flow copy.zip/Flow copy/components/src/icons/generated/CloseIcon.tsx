// AUTO-GENERATED from icons/close-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function CloseIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M5.46979 5.21381C5.76269 4.92092 6.23756 4.92092 6.53045 5.21381L18.5305 17.2139C18.8233 17.5068 18.8233 17.9817 18.5304 18.2745C18.2376 18.5674 17.7627 18.5674 17.4698 18.2745L5.46979 6.27447C5.1769 5.98157 5.1769 5.5067 5.46979 5.21381Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M18.5305 5.21381C18.8233 5.50671 18.8233 5.98158 18.5304 6.27447L6.53037 18.2745C6.23748 18.5674 5.76261 18.5674 5.46971 18.2745C5.17682 17.9816 5.17682 17.5067 5.46972 17.2138L17.4698 5.21381C17.7627 4.92092 18.2376 4.92092 18.5305 5.21381Z" fill="currentColor"/>
    </Icon>
  );
}
