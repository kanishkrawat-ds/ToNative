// AUTO-GENERATED from icons/play-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function PlayIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M6.99997 8.59343C6.99997 6.17624 8.54204 5.19749 10.4328 6.39868L15.5819 9.69081C17.4726 10.892 17.4726 12.8791 15.5819 14.0803L10.4328 17.3724C8.54204 18.5736 6.99997 17.5949 6.99997 15.1777V8.59343Z" fill="currentColor"/>
    </Icon>
  );
}
