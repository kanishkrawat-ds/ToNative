// AUTO-GENERATED from icons/arrow-downward-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowDownwardIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M5.51192 11.4315C5.82641 11.162 6.29989 11.1984 6.56946 11.5129L12 17.8485L17.4306 11.5129C17.7001 11.1984 18.1736 11.162 18.4881 11.4315C18.8026 11.7011 18.839 12.1746 18.5695 12.4891L12.9491 19.0462C12.4502 19.6282 11.5498 19.6282 11.0509 19.0462L5.43057 12.4891C5.161 12.1746 5.19743 11.7011 5.51192 11.4315Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M12 18.751C11.5858 18.751 11.25 18.4152 11.25 18.001L11.25 5.00098C11.25 4.58676 11.5858 4.25098 12 4.25098C12.4142 4.25098 12.75 4.58676 12.75 5.00098L12.75 18.001C12.75 18.4152 12.4142 18.751 12 18.751Z" fill="currentColor"/>
    </Icon>
  );
}
