// AUTO-GENERATED from icons/arrow-forward-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowForwardIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M11.4306 18.4881C11.161 18.1736 11.1974 17.7001 11.5119 17.4306L17.8476 12L11.5119 6.56946C11.1974 6.29989 11.161 5.82641 11.4306 5.51192C11.7001 5.19743 12.1736 5.161 12.4881 5.43057L19.0452 11.0509C19.6272 11.5498 19.6272 12.4502 19.0452 12.9491L12.4881 18.5695C12.1736 18.839 11.7001 18.8026 11.4306 18.4881Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M18.75 12C18.75 12.4142 18.4142 12.75 18 12.75L5 12.75C4.58579 12.75 4.25 12.4142 4.25 12C4.25 11.5858 4.58579 11.25 5 11.25L18 11.25C18.4142 11.25 18.75 11.5858 18.75 12Z" fill="currentColor"/>
    </Icon>
  );
}
