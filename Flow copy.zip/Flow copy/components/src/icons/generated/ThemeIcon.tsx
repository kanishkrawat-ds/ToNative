// AUTO-GENERATED from icons/theme-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ThemeIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2ZM12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5V3.5Z" fill="currentColor"/>
    </Icon>
  );
}
