// AUTO-GENERATED from icons/circle-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function CircleFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18Z" fill="currentColor"/>
    </Icon>
  );
}
