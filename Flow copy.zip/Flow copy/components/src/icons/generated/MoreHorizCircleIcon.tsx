// AUTO-GENERATED from icons/more-horiz-circle-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function MoreHorizCircleIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M8.56592 12C8.56592 12.8284 7.89434 13.5 7.06592 13.5C6.23749 13.5 5.56592 12.8284 5.56592 12C5.56592 11.1716 6.23749 10.5 7.06592 10.5C7.89434 10.5 8.56592 11.1716 8.56592 12Z" fill="currentColor"/> <path d="M13.5 12C13.5 12.8284 12.8284 13.5 12 13.5C11.1716 13.5 10.5 12.8284 10.5 12C10.5 11.1716 11.1716 10.5 12 10.5C12.8284 10.5 13.5 11.1716 13.5 12Z" fill="currentColor"/> <path d="M18.4341 12C18.4341 12.8284 17.7625 13.5 16.9341 13.5C16.1057 13.5 15.4341 12.8284 15.4341 12C15.4341 11.1716 16.1057 10.5 16.9341 10.5C17.7625 10.5 18.4341 11.1716 18.4341 12Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/>
    </Icon>
  );
}
