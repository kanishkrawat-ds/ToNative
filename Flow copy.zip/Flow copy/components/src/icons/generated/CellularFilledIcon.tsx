// AUTO-GENERATED from icons/cellular-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function CellularFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M17.6181 21.5654H9.27497C5.16511 21.5654 3.11018 21.5654 2.59878 20.3308C2.08738 19.0961 3.54043 17.6431 6.44654 14.737L14.7897 6.39383C17.6958 3.48773 19.1488 2.03467 20.3835 2.54607C21.6181 3.05748 21.6181 5.1124 21.6181 9.22226V17.5654C21.6181 19.451 21.6181 20.3938 21.0323 20.9796C20.4465 21.5654 19.5037 21.5654 17.6181 21.5654Z" fill="currentColor"/>
    </Icon>
  );
}
