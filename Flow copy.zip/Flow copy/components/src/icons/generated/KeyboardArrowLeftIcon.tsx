// AUTO-GENERATED from icons/keyboard-arrow-left-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function KeyboardArrowLeftIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M15.5762 17.4801C15.8414 17.1619 15.7984 16.689 15.4802 16.4238L10.1716 12L15.4802 7.57615C15.7984 7.31097 15.8414 6.83805 15.5762 6.51984C15.311 6.20163 14.8381 6.15864 14.5199 6.42381L8.82718 11.1677C8.30745 11.6009 8.30744 12.3991 8.82718 12.8322L14.5199 17.5761C14.8381 17.8413 15.311 17.7983 15.5762 17.4801Z" fill="currentColor"/>
    </Icon>
  );
}
