// AUTO-GENERATED from icons/more-horizontal-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function MoreHorizontalIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M7.61005 11.96C7.61005 13.0645 6.71462 13.96 5.61005 13.96C4.50548 13.96 3.61005 13.0645 3.61005 11.96C3.61005 10.8554 4.50548 9.95996 5.61005 9.95996C6.71462 9.95996 7.61005 10.8554 7.61005 11.96Z" fill="currentColor"/> <path d="M13.96 11.96C13.96 13.0645 13.0646 13.96 11.96 13.96C10.8555 13.96 9.96002 13.0645 9.96002 11.96C9.96002 10.8554 10.8555 9.95996 11.96 9.95996C13.0646 9.95996 13.96 10.8554 13.96 11.96Z" fill="currentColor"/> <path d="M20.31 11.96C20.31 13.0645 19.4146 13.96 18.31 13.96C17.2054 13.96 16.31 13.0645 16.31 11.96C16.31 10.8554 17.2054 9.95996 18.31 9.95996C19.4146 9.95996 20.31 10.8554 20.31 11.96Z" fill="currentColor"/>
    </Icon>
  );
}
