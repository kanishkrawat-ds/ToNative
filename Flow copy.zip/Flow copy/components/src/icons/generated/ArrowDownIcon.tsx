// AUTO-GENERATED from icons/arrow-down-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowDownIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M15.3141 9L8.68214 9C8.03311 9 7.69047 9.76846 8.12423 10.2512L11.4345 13.9357C11.7321 14.267 12.2512 14.2674 12.5494 13.9366L15.8711 10.2522C16.3061 9.76971 15.9637 9 15.3141 9Z" fill="currentColor"/>
    </Icon>
  );
}
