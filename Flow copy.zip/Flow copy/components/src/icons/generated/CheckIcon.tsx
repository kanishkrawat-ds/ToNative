// AUTO-GENERATED from icons/check-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function CheckIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M19.5064 6.44679C19.8119 6.72647 19.8329 7.20088 19.5532 7.50641L10.7578 17.1149C10.2718 17.6458 9.43908 17.6576 8.93817 17.1408L4.46145 12.522C4.17317 12.2246 4.18059 11.7497 4.47802 11.4615C4.77545 11.1732 5.25027 11.1806 5.53855 11.478L9.83055 15.9063L18.4468 6.4936C18.7265 6.18806 19.2009 6.1671 19.5064 6.44679Z" fill="currentColor"/>
    </Icon>
  );
}
