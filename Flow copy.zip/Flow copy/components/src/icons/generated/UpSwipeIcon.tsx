// AUTO-GENERATED from icons/up-swipe-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function UpSwipeIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M11.9982 11.25C8.70016 11.25 5.87302 12.1933 3.4632 14.0857C3.13743 14.3415 2.66595 14.2848 2.41013 13.959C2.15431 13.6332 2.21103 13.1617 2.5368 12.9059C5.23013 10.791 8.38957 9.75 11.9982 9.75C15.6068 9.75 18.7705 10.7963 21.4631 12.9101C21.7889 13.1658 21.8457 13.6373 21.5899 13.9631C21.3342 14.2889 20.8627 14.3457 20.5369 14.0899C18.1269 12.198 15.295 11.25 11.9982 11.25Z" fill="currentColor"/>
    </Icon>
  );
}
