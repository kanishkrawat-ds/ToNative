// AUTO-GENERATED from icons/info-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function InfoFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM11.25 12C11.25 11.5858 11.5858 11.25 12 11.25C12.4142 11.25 12.75 11.5858 12.75 12V16C12.75 16.4142 12.4142 16.75 12 16.75C11.5858 16.75 11.25 16.4142 11.25 16V12ZM11 8.5C11 9.05229 11.4477 9.5 12 9.5C12.5523 9.5 13 9.05228 13 8.5C13 7.94771 12.5523 7.5 12 7.5C11.4477 7.5 11 7.94772 11 8.5Z" fill="currentColor"/>
    </Icon>
  );
}
