// AUTO-GENERATED from icons/arrow-back-ios-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowBackIosIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M16.5606 3.50174C16.8358 3.81132 16.8079 4.28538 16.4983 4.56056L8.12892 12L16.4983 19.4395C16.8079 19.7146 16.8358 20.1887 16.5606 20.4983C16.2854 20.8079 15.8113 20.8358 15.5018 20.5606L6.92217 12.9343C6.36278 12.437 6.36278 11.563 6.92217 11.0657L15.5018 3.43945C15.8113 3.16426 16.2854 3.19215 16.5606 3.50174Z" fill="currentColor"/>
    </Icon>
  );
}
