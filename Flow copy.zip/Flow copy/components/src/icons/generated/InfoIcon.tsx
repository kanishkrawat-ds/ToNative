// AUTO-GENERATED from icons/info-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function InfoIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/> <path d="M11 8.49963C11 9.05192 11.4477 9.49963 12 9.49963C12.5523 9.49963 13 9.05192 13 8.49963C13 7.94735 12.5523 7.49963 12 7.49963C11.4477 7.49963 11 7.94735 11 8.49963Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M12 11.2496C11.5858 11.2496 11.25 11.5854 11.25 11.9996V15.9996C11.25 16.4138 11.5858 16.7496 12 16.7496C12.4142 16.7496 12.75 16.4138 12.75 15.9996V11.9996C12.75 11.5854 12.4142 11.2496 12 11.2496Z" fill="currentColor"/>
    </Icon>
  );
}
