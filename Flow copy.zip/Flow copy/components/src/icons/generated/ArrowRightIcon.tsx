// AUTO-GENERATED from icons/arrow-right-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowRightIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M10 8.90856L10 15.5405C10 16.1895 10.7685 16.5322 11.2512 16.0984L14.9357 12.7882C15.267 12.4905 15.2674 11.9714 14.9366 11.6732L11.2522 8.35152C10.7697 7.91653 10 8.25893 10 8.90856Z" fill="currentColor"/>
    </Icon>
  );
}
