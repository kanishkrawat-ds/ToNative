// AUTO-GENERATED from icons/keyboard-arrow-up-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function KeyboardArrowUpIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 10.1716L16.4239 15.4802C16.689 15.7984 17.1619 15.8414 17.4802 15.5762C17.7984 15.311 17.8414 14.8381 17.5762 14.5199L12.8323 8.82718C12.3991 8.30745 11.6009 8.30744 11.1678 8.82718L6.42385 14.5199C6.15868 14.8381 6.20167 15.311 6.51988 15.5762C6.83809 15.8414 7.31101 15.7984 7.57618 15.4802L12 10.1716Z" fill="currentColor"/>
    </Icon>
  );
}
