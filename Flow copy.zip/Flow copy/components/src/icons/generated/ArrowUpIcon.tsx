// AUTO-GENERATED from icons/arrow-up-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowUpIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M8.68604 14.9998L15.318 14.9998C15.967 14.9998 16.3097 14.2314 15.8759 13.7486L12.5656 10.0642C12.268 9.73289 11.7489 9.73245 11.4507 10.0632L8.129 13.7476C7.69401 14.2301 8.03641 14.9998 8.68604 14.9998Z" fill="currentColor"/>
    </Icon>
  );
}
