// AUTO-GENERATED from icons/keyboard-arrow-right-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function KeyboardArrowRightIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M8.42381 17.4801C8.15863 17.1619 8.20163 16.689 8.51983 16.4238L13.8284 12L8.51983 7.57615C8.20163 7.31097 8.15863 6.83805 8.42381 6.51984C8.68898 6.20163 9.1619 6.15864 9.48011 6.42381L15.1728 11.1677C15.6926 11.6009 15.6926 12.3991 15.1728 12.8322L9.48011 17.5761C9.1619 17.8413 8.68898 17.7983 8.42381 17.4801Z" fill="currentColor"/>
    </Icon>
  );
}
