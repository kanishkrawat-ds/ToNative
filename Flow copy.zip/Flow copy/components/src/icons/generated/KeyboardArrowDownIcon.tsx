// AUTO-GENERATED from icons/keyboard-arrow-down-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function KeyboardArrowDownIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M17.4801 8.42381C17.1619 8.15863 16.689 8.20163 16.4238 8.51983L12 13.8284L7.57615 8.51983C7.31097 8.20163 6.83805 8.15863 6.51984 8.42381C6.20163 8.68898 6.15864 9.1619 6.42381 9.48011L11.1677 15.1728C11.6009 15.6926 12.3991 15.6926 12.8322 15.1728L17.5761 9.48011C17.8413 9.1619 17.7983 8.68898 17.4801 8.42381Z" fill="currentColor"/>
    </Icon>
  );
}
