// AUTO-GENERATED from icons/close-sys-small.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function CloseSmallIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 16 17" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M11.0303 11.5303C10.7374 11.8232 10.2626 11.8232 9.96967 11.5303L4.96967 6.53033C4.67678 6.23743 4.67678 5.76256 4.96967 5.46967C5.26256 5.17678 5.73743 5.17678 6.03033 5.46967L11.0303 10.4697C11.3232 10.7626 11.3232 11.2374 11.0303 11.5303Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M4.9702 11.5303C4.67731 11.2374 4.67731 10.7626 4.9702 10.4697L9.9702 5.46967C10.2631 5.17678 10.738 5.17678 11.0309 5.46967C11.3238 5.76256 11.3238 6.23743 11.0309 6.53033L6.03086 11.5303C5.73797 11.8232 5.2631 11.8232 4.9702 11.5303Z" fill="currentColor"/> <path d="M9.061 8.50038L7.98629 9.57509L6.92563 8.51443L8.00034 7.43973L9.061 8.50038Z" fill="currentColor"/>
    </Icon>
  );
}
