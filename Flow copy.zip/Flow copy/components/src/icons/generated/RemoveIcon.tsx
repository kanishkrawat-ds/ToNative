// AUTO-GENERATED from icons/remove-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function RemoveIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M17.75 12.0005C17.75 12.4147 17.4142 12.7505 17 12.7505L7 12.7505C6.58579 12.7505 6.25 12.4147 6.25 12.0005C6.25 11.5863 6.58579 11.2505 7 11.2505L17 11.2505C17.4142 11.2505 17.75 11.5863 17.75 12.0005Z" fill="currentColor"/>
    </Icon>
  );
}
