// AUTO-GENERATED from icons/access-time-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function AccessTimeFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM12.75 7.5C12.75 7.08579 12.4142 6.75 12 6.75C11.5858 6.75 11.25 7.08579 11.25 7.5V12.2229C11.25 12.6539 11.472 13.0545 11.8375 13.2829L15.6025 15.636C15.9538 15.8555 16.4165 15.7488 16.636 15.3975C16.8555 15.0462 16.7488 14.5835 16.3975 14.364L12.75 12.0843V7.5Z" fill="currentColor"/>
    </Icon>
  );
}
