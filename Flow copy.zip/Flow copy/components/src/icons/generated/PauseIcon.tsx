// AUTO-GENERATED from icons/pause-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function PauseIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M9 5.99609C9.41421 5.99609 9.75 6.33188 9.75 6.74609V16.7461C9.75 17.1603 9.41421 17.4961 9 17.4961C8.58579 17.4961 8.25 17.1603 8.25 16.7461V6.74609C8.25 6.33188 8.58579 5.99609 9 5.99609Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M14.95 5.99609C15.3642 5.99609 15.7 6.33188 15.7 6.74609V16.7461C15.7 17.1603 15.3642 17.4961 14.95 17.4961C14.5357 17.4961 14.2 17.1603 14.2 16.7461V6.74609C14.2 6.33188 14.5357 5.99609 14.95 5.99609Z" fill="currentColor"/>
    </Icon>
  );
}
