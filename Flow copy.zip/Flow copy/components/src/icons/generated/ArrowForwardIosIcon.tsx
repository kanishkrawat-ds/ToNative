// AUTO-GENERATED from icons/arrow-forward-ios-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowForwardIosIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M7.43942 3.50174C7.16423 3.81132 7.19211 4.28538 7.5017 4.56056L15.8711 12L7.5017 19.4395C7.19211 19.7146 7.16423 20.1887 7.43942 20.4983C7.71461 20.8079 8.18866 20.8358 8.49825 20.5606L17.0778 12.9343C17.6372 12.437 17.6372 11.563 17.0778 11.0657L8.49825 3.43945C8.18866 3.16426 7.71461 3.19215 7.43942 3.50174Z" fill="currentColor"/>
    </Icon>
  );
}
