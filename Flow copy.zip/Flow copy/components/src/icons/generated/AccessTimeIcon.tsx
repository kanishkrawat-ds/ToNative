// AUTO-GENERATED from icons/access-time-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function AccessTimeIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M12 6.75C12.4142 6.75 12.75 7.08579 12.75 7.5V12.0843L16.3975 14.364C16.7488 14.5835 16.8555 15.0462 16.636 15.3975C16.4165 15.7488 15.9538 15.8555 15.6025 15.636L11.8375 13.2829C11.472 13.0545 11.25 12.6539 11.25 12.2229V7.5C11.25 7.08579 11.5858 6.75 12 6.75Z" fill="currentColor"/>
    </Icon>
  );
}
