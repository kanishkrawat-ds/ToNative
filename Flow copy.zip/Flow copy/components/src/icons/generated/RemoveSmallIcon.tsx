// AUTO-GENERATED from icons/remove-sys-small.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function RemoveSmallIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 16 17" {...props}>
      <path d="M4.66667 7.75031C4.25246 7.75031 3.91667 8.08609 3.91667 8.50031C3.91667 8.91452 4.25246 9.25031 4.66667 9.25031L11.3333 9.25031C11.7476 9.25031 12.0833 8.91452 12.0833 8.50031C12.0833 8.08609 11.7476 7.75031 11.3333 7.75031H4.66667Z" fill="currentColor"/>
    </Icon>
  );
}
