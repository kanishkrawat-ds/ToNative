// AUTO-GENERATED from icons/arrow-back-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowBackIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12.5687 5.51192C12.8383 5.82641 12.8019 6.29989 12.4874 6.56946L6.15173 12L12.4874 17.4306C12.8019 17.7001 12.8383 18.1736 12.5687 18.4881C12.2992 18.8026 11.8257 18.839 11.5112 18.5695L4.95409 12.9491C4.37208 12.4502 4.37207 11.5498 4.95409 11.0509L11.5112 5.43057C11.8257 5.161 12.2992 5.19743 12.5687 5.51192Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M5.24928 12C5.24928 11.5858 5.58507 11.25 5.99928 11.25H18.9993C19.4135 11.25 19.7493 11.5858 19.7493 12C19.7493 12.4142 19.4135 12.75 18.9993 12.75H5.99928C5.58507 12.75 5.24928 12.4142 5.24928 12Z" fill="currentColor"/>
    </Icon>
  );
}
