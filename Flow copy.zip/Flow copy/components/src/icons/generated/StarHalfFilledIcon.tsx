// AUTO-GENERATED from icons/star-half-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function StarHalfFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M11.0452 2.44589C11.2683 1.95715 12 2.11629 12 2.65355V17.3399C12 17.7963 11.7543 18.2173 11.3569 18.4418L7.35995 20.6995C6.41569 21.2329 5.28183 20.4091 5.4973 19.3462L6.41412 14.8239C6.50226 14.3891 6.35632 13.94 6.02946 13.64L2.62959 10.5203C1.83053 9.78709 2.26363 8.45415 3.34106 8.33064L7.92535 7.80512C8.36607 7.75459 8.74816 7.47699 8.9324 7.07345L11.0452 2.44589Z" fill="currentColor"/>
    </Icon>
  );
}
