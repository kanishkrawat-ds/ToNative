// AUTO-GENERATED from icons/arrow-left-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowLeftIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M14 15.3141L14 8.68214C14 8.03311 13.2315 7.69047 12.7488 8.12423L9.06434 11.4345C8.73304 11.7321 8.7326 12.2512 9.06338 12.5494L12.7478 15.8711C13.2303 16.3061 14 15.9637 14 15.3141Z" fill="currentColor"/>
    </Icon>
  );
}
