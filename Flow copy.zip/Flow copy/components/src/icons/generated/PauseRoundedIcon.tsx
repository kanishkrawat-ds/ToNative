// AUTO-GENERATED from icons/pause-rounded-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function PauseRoundedIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path d="M6.00317 7.5C6.00317 6.39543 6.8986 5.5 8.00317 5.5C9.10774 5.5 10.0032 6.39543 10.0032 7.5V16.5C10.0032 17.6046 9.10774 18.5 8.00317 18.5C6.8986 18.5 6.00317 17.6046 6.00317 16.5V7.5Z" fill="currentColor"/> <path d="M13.9968 7.5C13.9968 6.39543 14.8923 5.5 15.9968 5.5C17.1014 5.5 17.9968 6.39543 17.9968 7.5V16.5C17.9968 17.6046 17.1014 18.5 15.9968 18.5C14.8923 18.5 13.9968 17.6046 13.9968 16.5V7.5Z" fill="currentColor"/>
    </Icon>
  );
}
