// AUTO-GENERATED from icons/clear-circle-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ClearCircleIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 20.5C16.6944 20.5 20.5 16.6944 20.5 12C20.5 7.30558 16.6944 3.5 12 3.5C7.30558 3.5 3.5 7.30558 3.5 12C3.5 16.6944 7.30558 20.5 12 20.5ZM12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M8.59919 8.59955C8.89208 8.30666 9.36695 8.30666 9.65985 8.59955L15.6598 14.5996C15.9527 14.8924 15.9527 15.3673 15.6598 15.6602C15.367 15.9531 14.8921 15.9531 14.5992 15.6602L8.59919 9.66021C8.30629 9.36732 8.30629 8.89245 8.59919 8.59955Z" fill="currentColor"/> <path fillRule="evenodd" clipRule="evenodd" d="M15.6598 8.59955C15.9527 8.89245 15.9527 9.36732 15.6598 9.66021L9.65985 15.6602C9.36695 15.9531 8.89208 15.9531 8.59919 15.6602C8.30629 15.3673 8.30629 14.8924 8.59919 14.5996L14.5992 8.59955C14.8921 8.30666 15.367 8.30666 15.6598 8.59955Z" fill="currentColor"/>
    </Icon>
  );
}
