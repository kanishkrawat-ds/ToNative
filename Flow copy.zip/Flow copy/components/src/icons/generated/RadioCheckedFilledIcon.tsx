// AUTO-GENERATED from icons/radio-checked-f-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function RadioCheckedFilledIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22ZM16.5653 9.49286C16.8375 9.18064 16.8051 8.70688 16.4929 8.43468C16.1806 8.16249 15.7069 8.19494 15.4347 8.50716L10.7533 13.877L8.55111 11.4913C8.27015 11.1869 7.79566 11.168 7.49129 11.4489C7.18693 11.7299 7.16795 12.2044 7.4489 12.5087L9.9157 15.1811C10.3799 15.684 11.1778 15.6726 11.6276 15.1568L16.5653 9.49286Z" fill="currentColor"/>
    </Icon>
  );
}
