// AUTO-GENERATED from icons/arrow-right-alt-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowRightAltIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M18.75 12.0009C18.75 12.4151 18.4142 12.7509 18 12.7509L5 12.7509C4.58579 12.7509 4.25 12.4151 4.25 12.0009C4.25 11.5866 4.58579 11.2509 5 11.2509L18 11.2509C18.4142 11.2509 18.75 11.5866 18.75 12.0009Z" fill="currentColor"/> <path d="M15.2002 10.0864V13.9184C15.2002 14.5674 15.9687 14.9101 16.4514 14.4763L18.5803 12.5636C18.9116 12.266 18.912 11.7469 18.5813 11.4487L16.4524 9.52939C15.9699 9.0944 15.2002 9.4368 15.2002 10.0864Z" fill="currentColor"/>
    </Icon>
  );
}
