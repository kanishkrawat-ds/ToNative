// AUTO-GENERATED from icons/radio-unchecked-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function RadioUncheckedIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M12 20.5004C16.6944 20.5004 20.5 16.6948 20.5 12.0004C20.5 7.30595 16.6944 3.50037 12 3.50037C7.30553 3.50037 3.49995 7.30595 3.49995 12.0004C3.49995 16.6948 7.30553 20.5004 12 20.5004ZM12 22.0004C17.5228 22.0004 22 17.5232 22 12.0004C22 6.47752 17.5228 2.00037 12 2.00037C6.47711 2.00037 1.99995 6.47752 1.99995 12.0004C1.99995 17.5232 6.47711 22.0004 12 22.0004Z" fill="currentColor"/>
    </Icon>
  );
}
