// AUTO-GENERATED from icons/call-made-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function CallMadeIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M8.65918 6C8.65918 5.58579 8.99497 5.25 9.40918 5.25H17C17.9665 5.25 18.75 6.0335 18.75 7V14.5908C18.75 15.005 18.4142 15.3408 18 15.3408C17.5858 15.3408 17.25 15.005 17.25 14.5908V7.81069L6.53033 18.5303C6.23744 18.8232 5.76256 18.8232 5.46967 18.5303C5.17678 18.2374 5.17678 17.7625 5.46967 17.4697L16.1894 6.75H9.40918C8.99497 6.75 8.65918 6.41421 8.65918 6Z" fill="currentColor"/>
    </Icon>
  );
}
