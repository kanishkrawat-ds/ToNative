// AUTO-GENERATED from icons/arrow-down-left-sys.svg. Do not edit by hand.
import { Icon, type IconProps } from '../Icon';

export function ArrowDownLeftIcon(props: IconProps) {
  return (
    <Icon viewBox="0 0 24 24" {...props}>
      <path fillRule="evenodd" clipRule="evenodd" d="M15.3408 18C15.3408 18.4142 15.005 18.75 14.5908 18.75L7 18.75C6.0335 18.75 5.25 17.9665 5.25 17L5.25 9.40918C5.25 8.99497 5.58579 8.65918 6 8.65918C6.41421 8.65918 6.75 8.99497 6.75 9.40918L6.75 16.1893L17.4697 5.46967C17.7626 5.17678 18.2374 5.17678 18.5303 5.46967C18.8232 5.76256 18.8232 6.23744 18.5303 6.53033L7.81063 17.25L14.5908 17.25C15.005 17.25 15.3408 17.5858 15.3408 18Z" fill="currentColor"/>
    </Icon>
  );
}
